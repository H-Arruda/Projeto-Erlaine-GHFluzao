package com.ghflusao.repository;

import com.ghflusao.model.Bilhete;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BilheteRepository extends JpaRepository<Bilhete, Integer> {

    boolean existsByPassageiroId(Integer passageiroId);
}
